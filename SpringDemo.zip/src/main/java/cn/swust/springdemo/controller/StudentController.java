package cn.swust.springdemo.controller;

import cn.swust.springdemo.pojo.Student;
import cn.swust.springdemo.validation.OnCreate;
import cn.swust.springdemo.validation.OnEdit;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import org.apache.ibatis.annotations.Delete;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Controller
@RequestMapping("/student")
public class StudentController {
    List<Student> students = new ArrayList<>();
public StudentController(){
    Student student1 = new Student(1L,"5120215636","张","三","男");
    student1.setBirthday(LocalDate.of(2002,6,7));
    Student student2 = new Student(2L,"5120215637","李","四","男");
    student2.setBirthday(LocalDate.of(2003,7,7));
    Student student3 = new Student(3L,"5120215638","王","五","男");
    student3.setBirthday(LocalDate.of(2004,8,7));
    students.add(student1);
    students.add(student2);
    students.add(student3);
}
    @RequestMapping("")
    public String student(Model model){
        model.addAttribute("students",students);
        return "student/index";
    }

    @RequestMapping("/course")
    public String course(){
        return "student/course";
    }
    @GetMapping("/view")
    public String studentView(Model model,long id){
        int idx = getStudentIndexById(id);
        if(idx!=-1){
            model.addAttribute("student",students.get(idx));
        }
        return "student/studentPage";
    }
    @GetMapping("/add")
    public String studentView(Model model,Long id){

        if(id == null){
            model.addAttribute("student",new Student());
        } else {
            int idx = getStudentIndexById(id);
            if(idx!=-1){
                model.addAttribute("student",students.get(idx));
            } else {
                model.addAttribute("student",new Student());
            }
        }
        return "student/form";
    }
    @PostMapping("/add")
    @Operation(summary = "新增学生")
    @ResponseBody
    public String addStudent(@Validated(OnCreate.class) @RequestBody Student student){
//        if(bindingResult.hasErrors()) {
//            // 有错误是回到form，此处同时自动把bindingResult绑定到form.html视图
//            return "student/index";
//        }
       // 没有错误时添加该学生并重定向到 /student 显示所有学生
      // 未学生分配一个随机整数（此处不保证所有学生Id唯一）
            Long id = Math.round(Math.random() * 1000);
            student.setId(id);
            if(Objects.equals(student.getGender(), "M")){
                student.setGender("男");
            }else {
                student.setGender("女");
            }
            this.students.add(student);
            return "success";
    }
    @PostMapping("/update")
    public String updateStudent(@Validated(OnEdit.class) @RequestBody Student student,BindingResult bindingResult){
    if (bindingResult.hasErrors()){
        return "student/form";
    }
    for(Student student1 : students){
            if(student1.getId()==student.getId()){
                student1.setNo(student.getNo());
                student1.setFirstname(student.getFirstname());
                student1.setLastname(student.getLastname());
                student1.setBirthday(student.getBirthday());
                break;
            }
        }
        return "redirect:/student";
    }
    @GetMapping("/getAll")
    @ResponseBody
    public List<Student> getAll(){
        return this.students;
    }
    @DeleteMapping("/delete/{id}")
    public String deleteStu(@PathVariable long id){
        int idx = getStudentIndexById(id);
        if(idx!=-1){
            students.remove(idx);
        }
        return "redirect:/student";
    }

    private int getStudentIndexById(long id){
        for (int i = 0; i < students.size(); i++) {
            if(students.get(i).getId()==id){
                return i;
            }
        }
        return -1;
    }
}
