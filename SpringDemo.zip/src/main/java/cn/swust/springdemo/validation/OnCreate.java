package cn.swust.springdemo.validation;

import jakarta.validation.groups.Default;

public interface OnCreate extends Default {
}
